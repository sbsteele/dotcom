package com.rayv.androidsdk;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.rayv.androidsdk.RayVLog;

public class XmlUtils 
{
	public static Document getDocumentByXml(String xmlString)
	{
		Document doc = null;
		try
		{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			StringReader sr = new StringReader(xmlString);
			InputSource in = new InputSource(sr);
			doc = docBuilder.parse(in);
			doc.getDocumentElement();
			if (doc.getDocumentElement() != null)
				doc.getDocumentElement().normalize();
		}
		catch (ParserConfigurationException e)
		{
			RayVLog.RAYVLOG_ERROR("XmlUtils.getDocument ParserConfigurationException: "+e.toString());
			doc = null;
		}
		catch(SAXException e)
		{
			RayVLog.RAYVLOG_ERROR("XmlUtils.getDocument SAXException: "+e.toString());
			doc = null;
		}
		catch(IOException e)
		{
			RayVLog.RAYVLOG_ERROR("XmlUtils.getDocument IOException: "+e.toString());
			doc = null;
		}
		
		return doc;
	}
	
	public static Document getDocumentByURL(String metadataURL)
	{	
		Document doc = null;
		try 
		{
			InputStream	input = ConnManager.OpenHttpConnection(metadataURL);
			if(input != null)
			{
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder db = dbf.newDocumentBuilder();
				doc = db.parse(input);
				input.close();
			}
		}
		catch (IOException e) 
		{	
			RayVLog.RAYVLOG_ERROR("getURLData IOException: "+e.toString());
			e.printStackTrace();
			doc = null;
		} 
		catch (ParserConfigurationException e) 
		{
			RayVLog.RAYVLOG_ERROR("getURLData ParserConfigurationException: "+e.toString());
			e.printStackTrace();
			doc = null;
		} 
		catch (SAXException e) 
		{
			RayVLog.RAYVLOG_ERROR("getURLData SAXException: "+e.toString());
			e.printStackTrace();
			doc = null;
		}
		
		return doc;
	}
	
	public static Element getElement(Document doc, String tagName, int index) 
	{
		if (doc == null)
			return null;
		if (doc.getDocumentElement() == null) 
			return null;
		
		NodeList rows = doc.getDocumentElement().getElementsByTagName(tagName); 
		return (Element) rows.item(index);
	}

	public static int getSize(Document doc, String tagName) 
	{
		if (doc == null)
			return 0;
		if (doc.getDocumentElement() == null) 
			return 0;
		NodeList rows =	doc.getDocumentElement().getElementsByTagName(tagName);
		if (rows != null)
			return rows.getLength();
		return 0;
	}

	public static String getValue(Element e, String tagName) 
	{
		if (e == null)
			return null;
		try 
		{
			NodeList elements = e.getElementsByTagName(tagName);
			Node node = elements.item(0);
			NodeList nodes = node.getChildNodes();

			String s;

			for (int i = 0; i < nodes.getLength(); i++) 
			{
				s = (nodes.item(i)).getNodeValue().trim();
				if (s.equals("") || s.equals("\r")) 
				{
					continue;
				} 
				else
					return s;
			}
		} 
		catch (Exception ex) {}

		return null;
	}
}
