package com.rayv.androidsdk;

import com.rayv.androidsdk.R;

import java.util.ArrayList;
import java.util.HashMap;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class P2PInfoAdapter extends BaseAdapter 
{
	private Activity                           m_activity = null;
	private ArrayList<HashMap<String, String>> m_data = null;
	private static LayoutInflater              m_inflater = null;
	
	public P2PInfoAdapter(P2PInfoActivity p2pInfoActivity, int p2pinfoRow, ArrayList<HashMap<String, String>> data) 
	{
		this.m_activity = p2pInfoActivity;
		m_inflater = (LayoutInflater)m_activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.m_data = data;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		View view = convertView;
		ViewHolder holder = null;
		
		if (convertView == null) 
		{
			view = m_inflater.inflate(R.layout.p2pinfo_row, null);
			 
			holder = new ViewHolder();
			holder.title = (TextView) view.findViewById(R.id.title);
			holder.value = (TextView) view.findViewById(R.id.value);
			view.setTag(holder);
		} 
		else 
		{
			holder = (ViewHolder) view.getTag();
		}
		
		if(m_data.get(position).containsKey("title"))
		{
			holder.title.setText(m_data.get(position).get("title"));
		}
		
		if(m_data.get(position).containsKey("value"))
		{
			holder.value.setText(m_data.get(position).get("value"));
		}
		
		return view;
	}
	
	static class ViewHolder 
	{
		TextView title;
		TextView value;
	}
	
	@Override
	public int getCount() 
	{
		return m_data.size();
	}

	@Override
	public Object getItem(int position) 
	{
		return m_data.get(position);
	}

	@Override
	public long getItemId(int position)
	{
		return m_data.get(position).hashCode();
	}
	
	public void clearList() 
	{
		m_data.clear();
    }
	
	public void addList(ArrayList<HashMap<String, String>> data) 
	{
		clearList();
		this.m_data = data;
	    notifyDataSetChanged();
	}
}
