package com.rayv.androidsdk;

import com.rayv.androidsdk.R;

import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

import com.rayv.androidsdk.AndroidPlayerCore;
import com.rayv.androidsdk.RTSPServer;
import com.rayv.androidsdk.RayVLog;

public class P2PInfoActivity extends Activity
{
	private ListView       m_p2pList = null;
	private P2PInfoAdapter m_adapter = null;
	
	private ArrayList<HashMap<String, String>> mList  = null;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.p2pinfo);
		getP2PInfo();
		
		m_p2pList = (ListView)findViewById(R.id.p2plist);
		
		m_adapter = new P2PInfoAdapter(this, R.layout.p2pinfo_row, mList);
		m_p2pList.setAdapter(m_adapter);
		
		m_p2pList.setOnItemClickListener(listListener);
		
		Thread t = new Thread()
		{
			@Override
			public void run()
			{
				runnable.run();
			}
		};
		t.start();
	}
	
	private Handler handler = new Handler()
	{
		@Override
		public void handleMessage(Message msg)
		{
			m_adapter.addList(mList);
		}
	};
	
	private Runnable runnable = new Runnable() {

		@Override
		public void run() {
			getP2PInfo();
			handler.sendEmptyMessage(0);
			handler.postDelayed(this, 5000);
		}

	};
	
	private OnItemClickListener listListener = new OnItemClickListener()
	{
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position, long id)
		{
			getP2PInfo();
			m_adapter.addList(mList);
		}
	};

	private void getP2PInfo()
	{
		try
		{
			String xmlString = "";
			Document doc = null;
			Element element = null;
			
			mList = new ArrayList<HashMap<String,String>>();
			
			int activeDonors = 0;
			int activeDonorsKbps = 0;
			float activeDonorsMb = 0;
			int silentDonors = 0;
			int zombieDonors = 0;
			int pendingDonors = 0;
			
			xmlString =	AndroidPlayerCore.sharedAndroidPlayerCore().infoOfType("connection").get("connection").toString();
			doc = XmlUtils.getDocumentByXml(xmlString);
			
			element = XmlUtils.getElement(doc, "LocalAddress", 0);
			
			String network="";
			network = XmlUtils.getValue(element, "IP")+":"+XmlUtils.getValue(element, "Port")+" "; 
			element = XmlUtils.getElement(doc, "ExternalAddress", 0);
			network += XmlUtils.getValue(element, "IP")+":"+XmlUtils.getValue(element, "Port");
			
			addToList(AndroidPlayerCore.sharedAndroidPlayerCore().getServiceState().toString(), network);
			
			addToList("Channel "+RTSPServer.getChannel(), " ");
			
			xmlString = AndroidPlayerCore.sharedAndroidPlayerCore().infoOfType("grid").get("grid").toString();
			doc = XmlUtils.getDocumentByXml(xmlString);
			
			int size = XmlUtils.getSize(doc, "Peer");
			
			for(int i=0;i<size;i++)
			{
				element = XmlUtils.getElement(doc, "Peer", i);
				
				if(XmlUtils.getValue(element,"Uri").equals("Sum donors"))
				{
					addToList("Download", String.format("%s kbps %s mb", XmlUtils.getValue(element,"Bitrate_kbps"), XmlUtils.getValue(element,"Total_MB")));
				}
				else
				{
					if(parseIntToString(XmlUtils.getValue(element,"Alloc")) == 1000)
					{
						addToList("Sat "+XmlUtils.getValue(element,"Uri"), String.format("%s kbps %s %s mb channel %s", XmlUtils.getValue(element,"Bitrate_kbps"), XmlUtils.getValue(element,"Efficiency"), XmlUtils.getValue(element,"Total_MB"), XmlUtils.getValue(element,"Channel")));
					}
					else
					{
						String peerState = XmlUtils.getValue(element,"State");
						
						if(peerState.equalsIgnoreCase("Donor"))
						{
							activeDonors++;
							String bit = XmlUtils.getValue(element,"Bitrate_kbps");
							activeDonorsKbps += Float.parseFloat(bit);
							activeDonorsMb += Float.parseFloat(XmlUtils.getValue(element,"Total_MB"));
						}
						else if(peerState.equalsIgnoreCase("Silent Donor"))
						{
							silentDonors++;
						}
						else if(peerState.equalsIgnoreCase("Zombie Donor"))
						{
							zombieDonors++;
						}
						else if(peerState.equalsIgnoreCase("Pending Donor"))
						{
							pendingDonors++;
						}
					}
				}
			}
			
			if(activeDonors > 0)
			{
				addToList(String.format("%s Active Donors", activeDonors), String.format("%s kbps %s mb", activeDonorsKbps, activeDonorsMb));
			}
			
			int totalDonors = activeDonors + silentDonors + zombieDonors + pendingDonors;
			
			if(totalDonors > 0)
			{
				addToList(String.format("%s Total donors", totalDonors), String.format("%s pending %s silent %s zombie", pendingDonors, silentDonors, zombieDonors));
			}
		}
		catch (Exception e)
		{
			RayVLog.RAYVLOG_ERROR("an Exception happened.");
			e.printStackTrace();
		}
	}
	
	private void addToList(String title, String value)
	{
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("title", title);
		map.put("value", value);
		mList.add(map);
	}
	
	private Integer parseIntToString(String string)
	{
		StreamTokenizer t = new StreamTokenizer(new StringReader(string));
		int number = 0;
		t.resetSyntax();
		t.parseNumbers();
		try
		{
		    if (t.nextToken() == StreamTokenizer.TT_NUMBER)
		    {
		    	number = (int)t.nval;
		    }
		   
		    return number;
		}
		catch ( IOException e )
		{
			RayVLog.RAYVLOG_ERROR("an Exception parseIntToString happened.");
		    return number;
		}
	}
}
