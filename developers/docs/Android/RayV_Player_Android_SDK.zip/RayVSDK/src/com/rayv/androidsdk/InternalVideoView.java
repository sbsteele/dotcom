package com.rayv.androidsdk;

import android.content.Context;
import android.widget.VideoView;

public class InternalVideoView extends VideoView
{
	private RVVideoView m_rVVideoView = null;
	private boolean     m_wasPaused = false;
	/***
	 * Constructor of InternalVideoView
	 * @param context
	 */
	public InternalVideoView(Context context, RVVideoView videoView) 
	{
		super(context);
		m_rVVideoView = videoView;
	}
	
	/***
	 * Returns true, the view can be pause
	 */
	@Override
	public boolean canPause()
	{
		return true;
	}
	
	/***
	 * Return false
	 */
	@Override
	public boolean canSeekBackward()
	{
		return false;
	}
	
	/***
	 * Return false
	 */
	@Override
	public boolean canSeekForward()
	{
		return false;
	}

	/***	
	 * Returns true if the video is playing, else otherwise
	 */
	@Override
	public boolean isPlaying()
	{
		return super.isPlaying();
	}

	@Override
	public void pause()
	{
		RayVLog.RAYVLOG_DEBUG("InternalVideoView pause");
		super.stopPlayback(); 
		if (m_rVVideoView != null && m_rVVideoView.m_rtsp != null) {
			m_rVVideoView.m_rtsp.stop();
		}
			
		m_wasPaused = true;
	}
	
	@Override
	public void resume()
	{
		RayVLog.RAYVLOG_DEBUG("InternalVideoView resume");
		super.resume();
	}
	
	@Override
	public void start()
	{
		RayVLog.RAYVLOG_DEBUG("InternalVideoView start");
		if (m_wasPaused == true)
		{
			if (m_rVVideoView != null && m_rVVideoView.m_rtsp != null)
				m_rVVideoView.m_rtsp.start();
			m_wasPaused = false;
		}		
		super.start();
		
	}
	
	@Override
	public void stopPlayback()
	{
		RayVLog.RAYVLOG_DEBUG("InternalVideoView stopPlayback");
		super.stopPlayback();
	}
	
	@Override
	public void suspend()
	{
		RayVLog.RAYVLOG_DEBUG("InternalVideoView suspend");
		super.suspend();
	}
}
