package com.rayv.androidsdk;

import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.text.format.Time;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.rayv.androidsdk.R;
import com.rayv.androidsdk.RTSPServer.SessionErrorState;
import com.rayv.androidsdk.RTSPServer.SessionState;
import com.rayv.androidsdk.AndroidPlayerCore;
import com.rayv.androidsdk.InternalVideoView;


public class RVVideoView extends RelativeLayout implements RTSPServerEventHandler, AndroidPlayerCoreEventHandler, OnErrorListener, OnCompletionListener, OnPreparedListener
{
    public RTSPServer         m_rtsp = null;
    private InternalVideoView m_videoView = null;
    private ProgressBar       m_progressBar = null;
    private TextView          m_mediaState = null;
    private boolean           m_statusVisible = false;
    private boolean           m_buttonVisible = false;
    private int               m_numberOfMediaStateTapsCoutner = 0;
    private int               m_numberOfButtonsTapsCounter = 0;
    private Button            m_p2pinfoButton  = null;
    private String            m_channel = null;
    private Time              m_lastTapTime = null;
    private boolean           m_isP2PActivated = false;
    
    /**
	* RVVideoView constructor
	*/
    public RVVideoView(Context context) 
    {
		super(context);	
	
		LayoutParams layout = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		this.setGravity(Gravity.CENTER_VERTICAL|Gravity.CENTER_HORIZONTAL);
		this.setLayoutParams(layout);
		
		m_videoView = new InternalVideoView(context, this);
		layout = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
		m_videoView.setLayoutParams(layout);
		m_videoView.setId(0);
		m_videoView.setFocusable(true);
		this.addView(m_videoView, 0, layout);
		
		m_progressBar = new ProgressBar(context);
		layout = new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
		layout.addRule(RelativeLayout.CENTER_IN_PARENT);
		m_progressBar.setLayoutParams(layout);
		m_progressBar.setId(1);
		this.addView(m_progressBar, 1, layout);
		
		m_mediaState = new TextView(context);
		layout = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		layout.addRule(RelativeLayout.CENTER_IN_PARENT);
		m_mediaState.setPadding(0, 100, 0, 0);
		m_mediaState.setLayoutParams(layout);
		m_mediaState.setId(2);
		m_mediaState.setVisibility(View.GONE);
		this.addView(m_mediaState, 2, layout);
		
		m_p2pinfoButton = new Button(context);
		layout = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
		layout.addRule(RelativeLayout.ALIGN_LEFT);
		m_p2pinfoButton.setText("P2P Info");
		m_p2pinfoButton.setLayoutParams(layout);
		m_p2pinfoButton.setId(3);
		m_p2pinfoButton.setVisibility(View.GONE);
		this.addView(m_p2pinfoButton, 3, layout);
				
		m_videoView.setOnErrorListener(this);	
		m_videoView.setOnCompletionListener(this);
		m_videoView.setOnPreparedListener(this);
		
		m_progressBar.setVisibility(View.GONE);
		m_progressBar.setOnClickListener(m_progressBarListener);
		m_p2pinfoButton.setOnClickListener(m_p2pinfoButtonListener);
		
		AndroidPlayerCore.sharedAndroidPlayerCore().setEventHandler(this);		
    }
  
    private OnClickListener m_p2pinfoButtonListener = new OnClickListener() 
    {	
		@Override
		public void onClick(View v) 
		{
			m_isP2PActivated = true;
			Intent intent = new Intent(getContext(), P2PInfoActivity.class);
			getContext().startActivity(intent);
		}
	};
    
    private OnClickListener m_progressBarListener = new OnClickListener() 
    {	
		@Override
		public void onClick(View v) 
		{
			if (m_numberOfButtonsTapsCounter == 0) {
				m_lastTapTime = new Time();
				m_lastTapTime.setToNow();
			}
			Time currentTapTime = new Time();
			currentTapTime.setToNow();
			
			if (currentTapTime.toMillis(false) - m_lastTapTime.toMillis(false) >= 500) {
				m_numberOfButtonsTapsCounter = 1;
				m_numberOfMediaStateTapsCoutner = 1;
				m_lastTapTime = currentTapTime;
				return;
			}
			m_numberOfButtonsTapsCounter++;
			if (m_numberOfButtonsTapsCounter == 5) {
				m_buttonVisible = !m_buttonVisible;
				m_p2pinfoButton.setVisibility(getStatus(m_buttonVisible));
			}
			
			m_numberOfMediaStateTapsCoutner++;
			if (m_numberOfMediaStateTapsCoutner != 0 && m_numberOfMediaStateTapsCoutner % 2 == 0) {
				m_statusVisible = !m_statusVisible;
				m_mediaState.setVisibility(getStatus(m_statusVisible));
			}
		}
	};
	
	/**
	* RVVideoView setting channel video Uri. 
	* The Uri should be "rayv:"+channelkey, for example "rayv:iphone1demo"
	*/
    public void setVideoURI(Uri uri)
    {
    	if(uri.getScheme().equals("rayv"))
    	{
    		m_channel = uri.getSchemeSpecificPart(); 		
    		if (m_rtsp != null) 
    			m_rtsp.setChannel(m_channel);
    	}
    }
    
    public void start()
    {
    	RayVLog.RAYVLOG_DEBUG("RayVVideoView start");
		if (m_isP2PActivated == true) {
			resume();
			return;
		}
		
    	if (m_rtsp == null) {
        	startRTSP();
    	}
    	if (m_channel != null)
    		m_rtsp.setChannel(m_channel);
    }
    
	private void startRTSP()
    {
    	m_rtsp = new RTSPServer();
		m_rtsp.setEventHandler(this);
		m_rtsp.start();
    }
        
    private void stopRTSP()
    {
    	m_rtsp.stop();
		m_rtsp = null;
    }
	
	@Override
	public void mediaSegmentsReady(String url)
	{
		RayVLog.RAYVLOG_DEBUG("RayVVideoView mediaSegmentsReady");
		m_videoView.setVideoURI(Uri.parse(url));
		m_videoView.start();
	}
	
	public void setMediaController(MediaController controller)
	{
		controller.setAnchorView(m_videoView );
		m_videoView.setMediaController(controller);
	}
    
    /**
	* Stop playback
	*/
    public void stopPlayback()
    {
    	RayVLog.RAYVLOG_DEBUG("RayVVideoView stopPlayback");   	
    	if (m_rtsp != null)
		{
    		stopRTSP();
		}
    	m_videoView.stopPlayback();
    }

	/**
	* Pause
	*/
	public void pause()
	{
		RayVLog.RAYVLOG_DEBUG("RVVideoView pause");
		if (m_isP2PActivated == true) {
			m_isP2PActivated = false;
			return;
		}
		m_videoView.stopPlayback();
		if (m_rtsp != null)
			m_rtsp.stop();
	}
	
    
    /**
	* Resume
	*/
    public void resume()
    {
    	RayVLog.RAYVLOG_DEBUG("RVVideoView resume");
    	if (m_isP2PActivated == true) {
    		m_isP2PActivated = false;
    		return;
    	}
    	RayVLog.RAYVLOG_DEBUG("RVVideoView resume p2p was not activated");
    	m_rtsp.start();
    	m_videoView.start();
    }

	@Override
	public void onServiceEvent(AndroidPlayerCore.ServiceState serviceState)
	{
//		String textToDisplay = "Unknown State";
//		if (serviceState == ServiceState.SERVICE_SIGNED_OUT)
//    		textToDisplay  = "Signed Out";
//		if (serviceState == ServiceState.SERVICE_DURING_SIGN_IN)
//    		textToDisplay  = "During Sign In";
//		if (serviceState == ServiceState.SERVICE_SIGNED_IN)
//    		textToDisplay  = "Signed In";
//    	
//    	RayVLog.RAYVLOG_DEBUG("new service state: " + serviceState);
    	//m_serviceState.setText(textToDisplay);
	}
	
	@Override
    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) 
    {
    	RayVLog.RAYVLOG_ERROR("onError--->   what:" + what + "    extra:" + extra);
    	return true;
    }

	@Override
	public void onCompletion(MediaPlayer mp) 
	{
		RayVLog.RAYVLOG_DEBUG("onCompletion called");	
	}
	
	@Override
	public void onPrepared(MediaPlayer mp)
	{
		m_progressBar.setVisibility(View.GONE);
		m_mediaState.setVisibility(View.GONE);
		RayVLog.RAYVLOG_DEBUG("onPrepared called");	
	}
	
	@Override
	public void onNewDisplayState(SessionState sessionState, SessionErrorState sessionError, boolean finalError)
	{
		String textToDisplay = "";
		if(sessionState == SessionState.SESSION_INACTIVE)
		{
			m_mediaState.setVisibility(View.GONE);
			m_progressBar.setVisibility(View.GONE);
			return;
		}
		
		if(finalError)
		{
			m_mediaState.setVisibility(View.VISIBLE);
			m_progressBar.setVisibility(View.GONE);
			
			switch (sessionError) 
			{
				case SESSION_E_UNKNOWN_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorSessionUnknown);
					break;
				case SESSION_E_INVALIDCHANNEL_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorInvalidChannel);
					break;
				case SESSION_E_NOCHANNEL_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorNoChannel);
					break;
				case SESSION_E_USERPERMISSION_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorUserPermission);
					break;
				case SESSION_E_CONTAINERPERMISSION_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorContainerPermission);
					break;
				case SESSION_E_IPPERMISSION_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorIpPermission);
					break;
				case SESSION_E_CHANNELOFFLINE_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorChannelOffline);
					break;
				case SESSION_E_MEDIA_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorMedia);
					break;
				case SESSION_E_STANDALONE_UNALLOWED_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorStandaloneUnallowed);
					break;
				case SESSION_E_CHANNEL_BUSY_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorChannelBusy);
					break;				
				case SESSION_E_UPGRADE_REQUIRED_STR:
					textToDisplay = getContext().getString(R.string.RVSessionErrorUpgradeRequired);
					break;
				case SESSION_E_SUBSCRIPTION_TOKEN_REQUIRED_STR:
				case SESSION_E_INVALID_SUBSCRIPTION_TOKEN_STR:
				case SESSION_E_SUBSCRIPTION_TOKEN_EXPIRED_STR:
				case SESSION_E_INVALID_SUBSCRIPTION_CREDENTIALS_STR:
				case SESSION_E_INVALID_SUBSCRIPTION_SECURITY_CODE_STR:
				case SESSION_E_SUBSCRIPTION_REQUEST_FAILED_STR:
				default:
					textToDisplay = "";
					break;
			}
		}
		else
		{
			RayVLog.RAYVLOG_DEBUG("session state is " + sessionState);
			m_progressBar.setVisibility(View.VISIBLE);
			switch (sessionState) 
			{
				case SESSION_SIGNINGIN:
					textToDisplay =  getContext().getString(R.string.RVSessionStateSigningIn);
					break;
				case SESSION_JOINING:
					textToDisplay = getContext().getString(R.string.RVSessionStateJoining);
					break;
				case SESSION_CONTACTING:
					textToDisplay  = getContext().getString(R.string.RVSessionStateContacting);
					break;
				case SESSION_BUFFERING:
					textToDisplay  = getContext().getString(R.string.RVSessionStateBuffering);			
					break;
				case SESSION_WAITING_FOR_KEY_FRAME:
					textToDisplay  = getContext().getString(R.string.RVSessionStateWaitingKeyFrame); 		
					break;
				case SESSION_STREAMING:
					textToDisplay  = getContext().getString(R.string.RVSessionStatePlaying); 
					break;
				default:
					textToDisplay  = getContext().getString(R.string.RVServiceStateSignedIn);
					break;
			}
		}
		
    	m_mediaState.setText(textToDisplay);	
	}
	
	private int getStatus(boolean show)
	{
		if(show)
		{
			return View.VISIBLE;
		}
		return View.GONE;
	}
}

