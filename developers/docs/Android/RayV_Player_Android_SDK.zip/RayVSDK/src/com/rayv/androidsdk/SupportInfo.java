package com.rayv.androidsdk;


import com.rayv.androidsdk.AndroidPlayerCore;

public class SupportInfo 
{	
	public String getP2PInfo() 
	{
		String connection = AndroidPlayerCore.sharedAndroidPlayerCore().infoOfType("connection").get("connection").toString();
		String grid = AndroidPlayerCore.sharedAndroidPlayerCore().infoOfType("grid").get("grid").toString();
		String p2pInfo = connection +"\n"+grid;
		return p2pInfo;
	}
	
	public String getSupportLog() 
	{
		return AndroidPlayerCore.sharedAndroidPlayerCore().getSupportLog();
	}
	
	public String getSupportInfo() 
	{
		return AndroidPlayerCore.sharedAndroidPlayerCore().getInfoOfType("support");
	}
}
