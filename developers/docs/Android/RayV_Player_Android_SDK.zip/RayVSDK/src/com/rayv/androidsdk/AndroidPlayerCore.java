package com.rayv.androidsdk;

import java.util.HashMap;
import java.util.Map;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;


public class AndroidPlayerCore 
{
	private static AndroidPlayerCore g_core = null;

	private Context							m_appContext = null;
	private int 							m_versionMajor = 0;
	private int 							m_versionMinor = 0;
	private int 							m_versionRevision = 0;
	private int 							m_versionBuild = 0;
	private AndroidPlayerCoreEventHandler 	m_evtHandler = null;
	private String                          m_distributor = null;
	
	private static Handler g_internalHandlerService = null;
	private static final String SERVICE_STATE = "SERVICE_STATE";
	
	// NDK code
	private static native void _init(String distributor, String product, int verMajor, int verMinor, int verRevision, int verBuild);
	private static native void _start();
	private static native void _stop();
	private static native int _serviceState();
	private static native String _getInfoOfType(String channel);
	private static native String _getSupportLog();
	
	private AndroidPlayerCore() {}
	
	static
	{
		System.loadLibrary("live555");
		System.loadLibrary("glib");
	    System.loadLibrary("c-ares");
	    System.loadLibrary("protobuf");
	    System.loadLibrary("expat");
	    System.loadLibrary("asn1");
	    System.loadLibrary("wx");
	    System.loadLibrary("rayvmux"); 
	    System.loadLibrary("playersdk");
	    System.loadLibrary("rayv_android_p2pstreaming");
	}
	
	private enum ReachabilityStatus
	{
		NotReachable,
		ReachableViaWWAN,
		ReachableViaWIFI
	}
	
	public enum ServiceState
	{
		SERVICE_SIGNED_OUT, 		//!< The user is signed out.
		SERVICE_DURING_SIGN_IN, 	//!< When the user is signing in.
		SERVICE_SIGNED_IN, 			//!< The user is signed in.
	};
	
	/***
	 * @hide
	 */
	public Object clone() throws CloneNotSupportedException
	{
		throw new CloneNotSupportedException(); 
	}
	 
	/**
	* AndroidPlayerCore instance
	*/
	public static AndroidPlayerCore sharedAndroidPlayerCore()
	{
		if (null == g_core)
			RayVLog.RAYVLOG_DEBUG("AndroidPlayerCore sharedAndroidPlayerCore g_core is null");
		
		return g_core;
	}

	/**
	* Initialize player core with distributor and player version (major.minor.revision.build for example 1.01.123)
	*/
	public static AndroidPlayerCore initWithDistirbutor(Context appContext,
														String distributor, 
														int verMajor, 
														int verMinor,
														int verRevision,
														int verBuild)
	{
		if (g_core != null)
			return g_core;
		
		if (null == distributor)
		{
			RayVLog.RAYVLOG_FATAL("can't have more than one player core or distributor is nil");
			return null;
		}
		
		g_core = new AndroidPlayerCore();
		g_core.m_appContext = appContext;
		g_core.m_versionMajor = verMajor;
		g_core.m_versionMinor = verMinor;
		g_core.m_versionRevision = verRevision;
		g_core.m_versionBuild = verBuild;
		g_core.m_distributor = distributor;
		
		_init(distributor, "android", verMajor, verMinor, verRevision, verBuild);
		
		return g_core;
	}

	/**
	* Start player core (creates and initialize RayV Player SDK)
	*/
	public void start()
	{
		_start();
	}

	/**
	* Stop player core (destroys RayV Player SDK)
	*/
	public void stop()
	{
		_stop();
		g_core = null;
	}
	
	/***
	* Sets player core event handler
	*/
	public void setEventHandler(AndroidPlayerCoreEventHandler evtHandler)
	{
		m_evtHandler = evtHandler;
        g_internalHandlerService = new Handler() 
        {
        	public void handleMessage(Message msg)
        	{
        		Bundle b = msg.getData();
        		int serviceState = b.getInt(SERVICE_STATE);
        		
        		// pass the event to delegate
        		if (m_evtHandler != null)
        			m_evtHandler.onServiceEvent(ServiceState.values()[serviceState]);
        	}
        };
	}

	public final String getVersion()
	{
		return String.format("%d.%d.%d.%d", m_versionMajor, m_versionMinor, m_versionRevision, m_versionBuild);
	}
	
	public final String getDistributor()
	{
		return m_distributor;
	}
	
	public final String getPlatform()
	{
		return Build.MANUFACTURER + " " + Build.MODEL + " " + Build.PRODUCT;
	}
	
	public final ServiceState getServiceState()
	{
		int state = _serviceState();
		return ServiceState.values()[state];
	}	
	
	private final ReachabilityStatus getReachabilityStatus()
	{
		ConnectivityManager cm  = (ConnectivityManager)m_appContext.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = cm.getActiveNetworkInfo();
		
		if(networkInfo == null)
			return ReachabilityStatus.NotReachable;
		
		boolean connected = networkInfo.isConnected();
		if (!networkInfo.isConnected())
			return ReachabilityStatus.NotReachable;
		
		networkInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		connected = (networkInfo != null) && networkInfo.isAvailable() && networkInfo.isConnected();
		if (connected)
			return ReachabilityStatus.ReachableViaWIFI;
		return ReachabilityStatus.ReachableViaWWAN;
	}
	
	private final String reachabilityString()
	{
		ReachabilityStatus status = getReachabilityStatus();
		 switch (status)
		 {
		 	case NotReachable:
		 		return "Access Not Available";
		 	case ReachableViaWWAN:
				return "WWAN";
		 	case ReachableViaWIFI:
		 		return "WIFI";
		 	default:
		 		return "Unknown";
		 }
	}

	/***
	* Get RayV Player SDK internal information for debugging and support. 
	* Possible values for type are: "support"
	*/
	public Map<String, String> infoOfType(String type)
	{
		Map<String, String> playerInfo = new HashMap<String, String>();
		//connection, grid, engine, support
		if (type == "player" || type == "support")
		{
			playerInfo.put("Version", getVersion());
			playerInfo.put("SDK_version", getVersion());
			playerInfo.put("Device_model", getPlatform());
			playerInfo.put("Device_system_version", Build.VERSION.RELEASE);
			playerInfo.put("Reachability", reachabilityString());	
		}
		if (!type.equals("player"))
		{
			String infoOfType = getInfoOfType(type);
			playerInfo.put(type, infoOfType);
		}
		return playerInfo;	
	}
	
	public static void onOnServiceEvent(int prevServiceState, int newServiceState, int error) 
	{
		String msg = String.format("onOnServiceEvent: prevServiceState=%d, newServiceState=%d, error=%d", prevServiceState, newServiceState, error);
		RayVLog.RAYVLOG_DEBUG(msg);
	    		
		if (g_internalHandlerService != null)
		{
			Bundle b = new Bundle(); 
			b.putInt(SERVICE_STATE, newServiceState);
			Message m = Message.obtain(); 
			m.setData(b); 
			m.setTarget(g_internalHandlerService); 
			m.sendToTarget();
		}
	}
	
	/***
	 * Returns info of type, for debugging. Possible value of type is support
	 */
	public String getInfoOfType(String type)
	{
		 return _getInfoOfType(type);
	}
	
	/***
	 * Returns suppot log for debugging.
	 */
	public String getSupportLog()
	{
		 return _getSupportLog();
	}	
}
