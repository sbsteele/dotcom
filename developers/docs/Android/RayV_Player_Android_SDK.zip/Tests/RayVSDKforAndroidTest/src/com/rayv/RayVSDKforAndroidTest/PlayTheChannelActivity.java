package com.rayv.RayVSDKforAndroidTest;

import com.rayv.androidsdk.RVVideoView;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;

public class PlayTheChannelActivity  extends Activity {
    
	/** Called when the activity is first created. */
	private RVVideoView m_VideoView = null;
	private String      m_channel = null;
	

    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	super.onCreate(savedInstanceState);
    	Intent intent= getIntent();
    	m_channel = intent.getStringExtra("channelName");
    }
    
    @Override
    public void onStart()
    {
    	android.util.Log.d("PlayTheChannelActivity", "onStart");
    	super.onStart();
    	
    	if (m_VideoView != null) {
    		m_VideoView.start();
    	}
    	else {
    		m_VideoView = new RVVideoView(this);   
    		MediaController mediaController = new MediaController(this, false);
    		m_VideoView.setMediaController(mediaController);
        	m_VideoView.setVideoURI(Uri.parse("rayv:"+m_channel));
        	m_VideoView.start();
        	setContentView(m_VideoView);
    	}
    }
    
    @Override
    protected void onRestart() 
    {
    	android.util.Log.d("PlayTheChannelActivity", "onRestart");
    	super.onRestart();
    }
    
    @Override
    public void onStop() 
    {	
    	android.util.Log.d("PlayTheChannelActivity", "onStop");
    	super.onStop();
    	
    	if (m_VideoView != null) {
    		m_VideoView.stopPlayback();
    	}
    }
    
    @Override
    public void onResume() 
    {	
    	android.util.Log.d("PlayTheChannelActivity", "onResume");
    	super.onResume();
    	if (m_VideoView != null)
    		m_VideoView.resume();
    }
    
    @Override
    public void onDestroy() 
    {	
    	android.util.Log.d("PlayTheChannelActivity", "onDestroy");
    	super.onDestroy();
    	if (m_VideoView != null) {
    		m_VideoView.stopPlayback();
    	}
    	m_VideoView = null;
    }
    
    @Override
    public void onPause() 
    {	
    	android.util.Log.d("PlayTheChannelActivity", "onPause");
    	super.onPause();
    	if (m_VideoView != null)
    		m_VideoView.pause();
    }
}