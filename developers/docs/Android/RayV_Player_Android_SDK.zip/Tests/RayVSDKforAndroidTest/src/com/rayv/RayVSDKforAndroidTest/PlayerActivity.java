package com.rayv.RayVSDKforAndroidTest;

import com.rayv.androidsdk.SupportInfoActivity;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class PlayerActivity extends Activity {
    
	/** Called when the activity is first created. */
	private EditText m_channelText = null;
	private Button   m_playChannelButton = null;
	private Button   m_supportInfo = null;
	    
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        android.util.Log.d("PlayerActivity", "onCreate");
        
    	drawButtons();
    }
    
    private void drawButtons() 
	{
		setContentView(R.layout.main);
		m_channelText = (EditText) findViewById(R.id.channelName);
		m_playChannelButton = (Button) findViewById(R.id.playChannel);
		m_supportInfo = (Button) findViewById(R.id.supportInfo);
		m_playChannelButton.setVisibility(View.VISIBLE);
		m_supportInfo.setVisibility(View.VISIBLE);
	}
		
	public void onPlayChannelClick(View v) 
	{
		Intent intent = new Intent(this, PlayTheChannelActivity.class);
		intent.putExtra("channelName", m_channelText.getText().toString());
		this.startActivity(intent);     
	}

	public void onSupportInfoClick(View v) 
	{
		Intent intent = new Intent(this, SupportInfoActivity.class);
		this.startActivity(intent);
	}
	
    @Override
    public void onStop() 
    {	
    	android.util.Log.d("PlayerActivity", "onStop");
    	super.onStop();
    }
    
    @Override
    public void onResume() 
    {	
    	android.util.Log.d("PlayerActivity", "onResume");
    	super.onResume();
    }
    
    @Override
    public void onDestroy() 
    {	
    	android.util.Log.d("PlayerActivity", "onDestroy");
    	super.onDestroy();
    }
    
    @Override
    public void onPause() 
    {	
    	android.util.Log.d("PlayerActivity", "onPause");
    	super.onPause();
    }
}