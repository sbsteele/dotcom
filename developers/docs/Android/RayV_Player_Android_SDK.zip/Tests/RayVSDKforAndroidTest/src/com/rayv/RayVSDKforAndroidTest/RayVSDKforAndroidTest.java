package com.rayv.RayVSDKforAndroidTest;

import com.rayv.androidsdk.AndroidPlayerCore;

import android.app.Application;

public class RayVSDKforAndroidTest extends Application  {
	
	private AndroidPlayerCore playerCore;
	
	@Override
	public void onCreate() 
	{
	    super.onCreate();	    
	    // Initialize SDK
	    playerCore = AndroidPlayerCore.initWithDistirbutor(this, "rayv", 2, 0, 0, 0);
	    playerCore.start();
        android.util.Log.d("RayVSDKforAndroidTest:onCreate", "SDK started...");
	}
	
	@Override
	public void onTerminate()
	{
		super.onTerminate();

		android.util.Log.d("RayVSDKforAndroidTest:onCreate", "SDK terminating...");
		
		if (playerCore != null)
			playerCore.stop();
	}
}