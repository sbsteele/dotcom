package com.rayv.androidsdk;

import com.rayv.androidsdk.R;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class SupportLogActivity extends Activity 
{
	private TextView m_logView = null;
	
	/**
	 * Called when the activity is first created.
	 */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.support_log);
		
		m_logView = (TextView)findViewById(R.id.log);
		m_logView.setText(this.getSupportString());
	}

	private String getSupportString() 
	{
		SupportInfo support = new SupportInfo();
		String text = support.getP2PInfo()+"\n"+support.getSupportInfo()+"\n"+support.getSupportLog();
		if(text.equals(""))
		{
			text = "No Log File :(";
		}		
		return text;
	}	
}
