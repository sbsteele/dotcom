package com.rayv.androidsdk;

import com.rayv.androidsdk.R;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class SupportInfoAdapter extends BaseAdapter{

	private String[]              m_supportInfo = null;
	private Activity              m_activity = null;
	private static LayoutInflater m_inflater = null;

	public SupportInfoAdapter(Activity supportActivity, String[] data) 
	{
		this.m_activity = supportActivity;
		m_inflater = (LayoutInflater)m_activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.m_supportInfo = data;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	{
		ViewHolder holder;
		 if (convertView == null) 
		 {
			 convertView = m_inflater.inflate(R.layout.support_info_row, null);
			 holder = new ViewHolder();
			 holder.title = (TextView) convertView.findViewById(R.id.title);
			 holder.value = (TextView) convertView.findViewById(R.id.value);
			 convertView.setTag(holder);
		 } 
		 else 
		 {
			 holder = (ViewHolder) convertView.getTag();
		 }
		 
		 if(m_supportInfo[position] == null)
		 {
			 return convertView;
		 }
		 
		 String[] data = m_supportInfo[position].split("\\|");
		 
		 holder.title.setText(data[0]);
		 holder.value.setText(data[1]);
		 return convertView;
	}
	
	public static class ViewHolder 
	{
		public TextView title;
		public TextView value;
	}
	
	@Override
	public int getCount() 
	{
		if (m_supportInfo == null)
			return 0;
		return m_supportInfo.length;
	}

	@Override
	public Object getItem(int position) 
	{	
		if (m_supportInfo == null)
			return null;
		return m_supportInfo[position];
	}

	@Override
	public long getItemId(int position) 
	{
		if (m_supportInfo == null)
			return 0;
		return m_supportInfo[position].hashCode();
	}
}
