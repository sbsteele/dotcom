package com.rayv.androidsdk;


public interface AndroidPlayerCoreEventHandler 
{
	void onServiceEvent(AndroidPlayerCore.ServiceState serviceState);
}
