package com.rayv.androidsdk;


public interface RTSPServerEventHandler
{
	// enough segments to start playing
	void mediaSegmentsReady(String url);
	
	// session event
	/*void onSessionEvent(RTSPServer.SessionState sessionState, 
						RTSPServer.MediaState mediaState, 
						boolean finalError);*/
	// session event
	void onNewDisplayState(RTSPServer.SessionState displayState, RTSPServer.SessionErrorState sessionError, boolean finalError);
	
}
