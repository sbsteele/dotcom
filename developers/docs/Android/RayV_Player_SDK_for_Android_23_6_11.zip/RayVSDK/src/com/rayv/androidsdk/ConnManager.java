package com.rayv.androidsdk;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;

import android.net.ConnectivityManager;
import com.rayv.androidsdk.RayVLog;

public class ConnManager 
{
	public static boolean checkInternetConnection(ConnectivityManager cm)
	{
		return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isAvailable() && cm.getActiveNetworkInfo().isConnected();
	}
	
	public static InputStream OpenHttpConnection(String strURL)
	{
		InputStream inputStream = null;
		
		try
		{
			URL url = new URL(strURL);
			URLConnection conn = url.openConnection();
			conn.setUseCaches(true);
			HttpURLConnection httpConn = (HttpURLConnection) conn;
			httpConn.setRequestMethod("GET");
			httpConn.connect();

			if (httpConn.getResponseCode() == HttpURLConnection.HTTP_OK)
			{
				inputStream = httpConn.getInputStream();
			}
		}
		catch(UnknownHostException e)
		{
			RayVLog.RAYVLOG_ERROR("UnknownHostException in OpenHttpConnection:"+e.toString());
			e.printStackTrace();
			inputStream = null;
		}
		catch (IOException e)
		{
			RayVLog.RAYVLOG_ERROR("Exception in OpenHttpConnection:"+e.toString());
			e.printStackTrace();
			inputStream = null;
		}
		
		return inputStream;
	}
}
