package com.rayv.androidsdk;

import com.rayv.androidsdk.R;

import java.io.StringReader;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.xml.sax.InputSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import com.rayv.androidsdk.AndroidPlayerCore;
import com.rayv.androidsdk.RayVLog;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;


public class SupportInfoActivity extends Activity 
{	
	private SupportInfoAdapter m_adapterDevice = null;
	private SupportInfoAdapter m_adapterConnection = null;
	private SupportInfoAdapter m_adapterChannel = null;
	
	private String[] m_device_info = null;
	private String[] m_connection_info = null;
	private String[] m_channel_info = null;
	
	private static final int LOG = Menu.FIRST;
	private static final int LOG_COPY = Menu.FIRST + 1;
	
	/**
	 * Called when the activity is first created.
	 */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.support_info);
			
		Map<String, String> supportInfo = AndroidPlayerCore.sharedAndroidPlayerCore().infoOfType("support");	
		if(supportInfo != null)
		{
			String strXml = supportInfo.get("support").toString();
			supportInfo.remove("support");
			
			if(strXml != null)
			{			
				LoadConnectionList(strXml);
				LoadChannelInfoList(strXml);	
			}
			
			m_device_info = getDeviceInfo(supportInfo);		
			LoadDeviceInfoList(m_device_info);
		}
	}
	
	private void LoadDeviceInfoList(String[] device_info2) 
	{
		ListView m_listDevicesView = (ListView)findViewById(R.id.list_device);
		m_listDevicesView.setClickable(false);
		
		if(m_device_info.length > 0)
		{
			m_adapterDevice = new SupportInfoAdapter(this, m_device_info);
			m_listDevicesView.setAdapter(m_adapterDevice);
		}
	}

	private void LoadChannelInfoList(String xmlString) 
	{
		ListView m_listChannelsView = (ListView)findViewById(R.id.list_channel);
		m_listChannelsView.setClickable(false);
		
		m_channel_info = getInfo(xmlString, "Channel_Player");
		m_adapterChannel = new SupportInfoAdapter(this, m_channel_info);
		m_listChannelsView.setAdapter(m_adapterChannel);
	}

	private void LoadConnectionList(String xmlString)
	{
		ListView m_listConnectionsView = (ListView)findViewById(R.id.list_connection);
		m_listConnectionsView.setClickable(false);
		
		m_connection_info = getInfo(xmlString, "Connection");
		m_adapterConnection = new SupportInfoAdapter(this, m_connection_info);
		m_listConnectionsView.setAdapter(m_adapterConnection);	
	}
	

	/**
	 * Get the Information support data
	 * @param xmlString String in xml format
	 * @param info type of info to get
	 * @return Array of data
	 */
	private String[] getInfo(String xmlString, String info) {
		
		try
		{
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			StringReader sr = new StringReader(xmlString);
			InputSource in = new InputSource(sr);
			Document doc = docBuilder.parse(in);

	        NodeList nodelist = doc.getElementsByTagName(info).item(0).getChildNodes();
			
			String[] str = new String[nodelist.getLength()];
			
			for (int i = 0; i < nodelist.getLength(); i++)
			{
				Node node = nodelist.item(i);
				if (node.getNodeType() == Node.ELEMENT_NODE)
				{
					Element elementKey = (Element) node;
					if (elementKey == null) {
						continue;
					}
					String name = node.getNodeName();
					NodeList elementKeyList = elementKey.getElementsByTagName(name);
					Element firstKeyElement = (Element) elementKeyList.item(0);
					NodeList firstKey = null;
					if (firstKeyElement == null) {
						firstKey = elementKey.getChildNodes();
					}
					else {
						firstKey = firstKeyElement.getChildNodes();
					}
					if (firstKey == null)
						continue;
					
					name = name.replace('_', ' ');
					
					if(firstKey.getLength()>0)
					{
						str[i] =name+"|" +(firstKey.item(0)).getNodeValue();
					}
					else
					{
						str[i] =name+"| ";
					}
				}
			}
			
			return str;
		}
		catch (Exception e)
		{
			RayVLog.RAYVLOG_ERROR("an Exception happened.");
			e.printStackTrace();
			// System.exit(1);
		}
		return null;
	}

	private String[] getDeviceInfo(Map<String, String> data) 
	{
		Object[] info_key = data.keySet().toArray();
		Object[] info_value = data.values().toArray();
		
		String[] str = new String[info_key.length+1];
		//tbd tbd add distributor
		str[0] = "Distributor|"+AndroidPlayerCore.sharedAndroidPlayerCore().getDistributor();
		
		int j=1;
		for(int i=0; i<info_key.length;i++)
		{
			str[j] = info_key[i].toString().replace('_', ' ');
			str[j] += "|"+info_value[i].toString();
			j++;
		}
		
		return str;
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		super.onCreateOptionsMenu(menu);
		menu.add(0, LOG, 0, "Log").setIcon(android.R.drawable.ic_menu_agenda);
		menu.add(0, LOG_COPY, 0, "Copy").setIcon(android.R.drawable.ic_menu_send);
		return true;
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		super.onOptionsItemSelected(item);

		switch (item.getItemId())
		{
			case LOG:
				Intent intent = new Intent(SupportInfoActivity.this, SupportLogActivity.class);
				startActivity(intent);
				return true;
			case LOG_COPY:
				CopyToClipboard();
				return true;
			default:
				return super.onOptionsItemSelected(item);
		}
	}

	private void CopyToClipboard() 
	{
		ClipboardManager clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);	
		SupportInfo support = new SupportInfo();
		clipboard.setText(support.getP2PInfo()+"\n"+support.getSupportInfo()+"\n"+support.getSupportLog());
		String msg = "Support log copied to clipboard";
		
		Toast toast = Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT);
		toast.show();
	}
}
