package com.rayv.androidsdk;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;


/**
 * RTSP Server
 */
public class RTSPServer
{
	private RTSPServerEventHandler m_evtHandler = null;
	private static Handler         g_internalHandler = null;
	private static Handler         g_internalHandlerSession = null;
	private static final String RTSP_URL = "rtsp_url";
	
	private static final String MEDIA_STATE = "MEDIA_STATE";
	private static final String SESSION_STATE = "SESSION_STATE";
	private static final String SESSION_ERROR = "SESSION_ERROR";
	private static final String ERROR = "ERROR";
	
	private	String m_rtsp_url = null; 
	
	public static native void _start();
	public static native void _stop();
	public static native void _setChannel(String channel);
	public static native String _getChannel();
	public static native void _onResult(String result);

		
	public enum SessionState
	{
		SESSION_INACTIVE,			//!< A non active session
		SESSION_SIGNINGIN,			//!< During sign in process
		SESSION_JOINING,			//!< When joining a channel
		SESSION_JOINED,				//!< When the channel is joined
		
		SESSION_CONTACTING,
		SESSION_BUFFERING,
		SESSION_WAITING_FOR_KEY_FRAME,
		SESSION_STREAMING
	}

	public enum MediaState
	{
		CHANNEL_MEDIA_INACTIVE,	 	//!< A non active channel
		CHANNEL_MEDIA_CONTACTING, 	//!< The engine is contacting other peers
		CHANNEL_MEDIA_BUFFERING, 	//!< The engine is buffering
		CHANNEL_MEDIA_STREAMING 	//!< When the channel is giving data
	}
	
	public enum SessionErrorState
	{
		SESSION_E_UNKNOWN_STR,
		SESSION_E_NOCHANNEL_STR,
		SESSION_E_INVALIDCHANNEL_STR,
		SESSION_E_USERPERMISSION_STR,
		SESSION_E_CONTAINERPERMISSION_STR,
		SESSION_E_IPPERMISSION_STR,
		SESSION_E_CHANNELOFFLINE_STR,
		SESSION_E_MEDIA_STR,
		SESSION_E_STANDALONE_UNALLOWED_STR,
		SESSION_E_CHANNEL_BUSY_STR,
		SESSION_E_SUBSCRIPTION_TOKEN_REQUIRED_STR,
		SESSION_E_INVALID_SUBSCRIPTION_TOKEN_STR,
		SESSION_E_SUBSCRIPTION_TOKEN_EXPIRED_STR,
		SESSION_E_UPGRADE_REQUIRED_STR,
		SESSION_E_INVALID_SUBSCRIPTION_CREDENTIALS_STR,
		SESSION_E_INVALID_SUBSCRIPTION_SECURITY_CODE_STR,
		SESSION_E_SUBSCRIPTION_REQUEST_FAILED_STR
	}

	public RTSPServer()
	{	
    };	   
    
	public void setEventHandler(RTSPServerEventHandler evtHandler)
	{
		m_evtHandler = evtHandler;
		
		// jni event handler
		g_internalHandler = new Handler() 
        {
        	public void handleMessage(Message msg)
        	{
        		Bundle b = msg.getData();
        		m_rtsp_url = b.getString(RTSP_URL);
        		
        		// pass the event to delegate
        		if (m_evtHandler != null)
        		{
        			m_evtHandler.mediaSegmentsReady(m_rtsp_url);
        			m_evtHandler.onNewDisplayState(SessionState.SESSION_STREAMING, SessionErrorState.SESSION_E_UNKNOWN_STR, false);
        		}
        	}
        };
        
        g_internalHandlerSession = new Handler() 
        {
        	public void handleMessage(Message msg)
        	{
        		Bundle b = msg.getData();
        		int mediaState = b.getInt(MEDIA_STATE);
        		int sessionState = b.getInt(SESSION_STATE);
        		int sessionError = b.getInt(SESSION_ERROR);
        		boolean error = b.getBoolean(ERROR);
        		SessionState displayState = SessionState.values()[sessionState];
        		SessionErrorState errorState = SessionErrorState.values()[sessionError];
        		
        		// pass the event to delegate
        		if (m_evtHandler != null)
        		{ 
        			// if session state is joined then use media state
        			if (SessionState.SESSION_JOINED.ordinal() == sessionState)
        			{
        				// contacting (in case media contacting event will not arrive)
        				if(MediaState.CHANNEL_MEDIA_INACTIVE.ordinal() == mediaState )
        				{
        					// ignore media inactive when channel is being stopped
        					if (sessionState != SessionState.SESSION_JOINING.ordinal())
        					{
        						RayVLog.RAYVLOG_DEBUG("ignoring CHANNEL_MEDIA_INACTIVE state when not joining");
        						return;
        					}
        					
        					displayState = SessionState.SESSION_CONTACTING;
        				}
        				// contacting
        				else if (MediaState.CHANNEL_MEDIA_CONTACTING.ordinal() == mediaState)
        				{
        					displayState = SessionState.SESSION_CONTACTING;
        				}		
        				// buffering
        				else if (MediaState.CHANNEL_MEDIA_BUFFERING.ordinal() == mediaState)
        				{
        					displayState = SessionState.SESSION_BUFFERING;
        				}
        				else if (MediaState.CHANNEL_MEDIA_STREAMING.ordinal() == mediaState)
        				{
        					displayState = SessionState.SESSION_WAITING_FOR_KEY_FRAME;
        				}		
        				else
        				{
        					RayVLog.RAYVLOG_WARNING("invalid media state for joined channel");
        					RayVLog.RAYVLOG_WARNING(String.format("MediaState:%d SessionState:%d ErrorState:%d", mediaState, sessionState, sessionError));
        				}
        			}
        			        			
        			m_evtHandler.onNewDisplayState(displayState, errorState, error);
        		}
        	}
        };
	}
	
	/***
	 * Starts RTSP server
	 */
	public void start()
	{
		RayVLog.RAYVLOG_DEBUG("RTSPServer start");
		_start();
	}
	
	/***
	 * Stops RTSP server
	 */
	public void stop()
	{
		_stop();
	}
	
	/***
	 * Sets channel to play
	 */
	public void setChannel(String channel)
	{
		_setChannel(channel);
	}
	
	static public String getChannel()
	{
		return _getChannel();
	}	
	
	public static void onMediaSegmentsReady(String url) 
	{
		RayVLog.RAYVLOG_DEBUG("onMediaSegmentsReady: " + url);
	    			
		Bundle b = new Bundle(); 
		b.putString(RTSP_URL, url); 
		Message m = Message.obtain(); 
		m.setData(b); 
		m.setTarget(g_internalHandler); 
		m.sendToTarget();	
	}
	
	public static void onOnSessionEvent(int prevSessionState, int newSessionState,
										int prevMediaState,   int newMediaState,
										int sessionError,     int finalError) 
	{
		String msg = String.format("onOnSessionEvent: prevSessionState=%d, newSessionState=%d, prevMediaState=%d, newMediaState=%d, errorState=%d, finalError=%d", prevSessionState, newSessionState, prevMediaState, newMediaState, sessionError, finalError);
		RayVLog.RAYVLOG_DEBUG(msg);
		if (g_internalHandler != null)
		{
			Bundle b = new Bundle();
			
			b.putInt(SESSION_STATE, newSessionState);
			b.putInt(MEDIA_STATE, newMediaState);
			b.putInt(SESSION_ERROR, sessionError);
			b.putBoolean(ERROR, finalError != 0);
			
			Message m = Message.obtain(); 
			m.setData(b); 
			m.setTarget(g_internalHandlerSession); 
			m.sendToTarget();
		}
	}
	
	public static void getHttpRequest(String stringURL)
	{	
		android.util.Log.d("HttpRequest", "Start, the URL " + stringURL);
		try 
        {
		  URL myurl = new URL(stringURL);
		  HttpsURLConnection con = (HttpsURLConnection)myurl.openConnection();
          InputStream ins = con.getInputStream();
          InputStreamReader isr = new InputStreamReader(ins);
          BufferedReader in = new BufferedReader(isr);


          String result = null;
          String inputLine;

          while ((inputLine = in.readLine()) != null)
          {
        	  if (result == null)
        		  result = inputLine;
        	  else
        		  result += inputLine;
        	  android.util.Log.d("HttpRequest", "Response = : "+inputLine);
          }

          in.close();
		  
          android.util.Log.d("HttpRequest", "The response is "+result);
          _onResult(result);
          return;
        }
        catch (Exception e) {
			// TODO Auto-generated catch block
        	
			android.util.Log.d("HttpRequest", "Exception: "+e.getMessage());
		}	
        android.util.Log.d("HttpRequest", "Ending");
        android.util.Log.d("HttpRequest", "The response is null");
	}
}
