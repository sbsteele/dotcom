package com.rayv.androidsdk;


public class RayVLog
{
	public static void RAYVLOG_FATAL(String msg)
	{
		android.util.Log.e("RayV_SDK", msg);
	}
	
	public static void RAYVLOG_ERROR(String msg)
	{
		android.util.Log.e("RayV_SDK", msg);
	}
	
	public static void RAYVLOG_WARNING(String msg)
	{
		android.util.Log.w("RayV_SDK", msg);
	}
	
	public static void RAYVLOG_DEBUG(String msg)
	{
		android.util.Log.d("RayV_SDK", msg);
	}
}
