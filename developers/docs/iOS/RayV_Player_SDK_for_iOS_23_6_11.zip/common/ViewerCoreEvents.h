/*
 *  ViewerCoreEvents.h
 *  RayV_Agent
 *
 *  Created by ost on 5/21/10.
 *  Copyright 2010 RayV. All rights reserved.
 *
 */

// event dictionary keys
extern NSString* RVEventSessionID;
extern NSString* RVEventNewSessionState;
extern NSString* RVEventPrevSessionState;
extern NSString* RVEventNewMediaState;
extern NSString* RVEventPrevMediaState;
extern NSString* RVEventError;
extern NSString* RVEventFinalError;
extern NSString* RVEventNewServiceState;
extern NSString* RVEventPrevServiceState;
extern NSString* RVEventSubscriptionConfig;
extern NSString* RVEventSubscriptionName;
extern NSString* RVEventSubscriptionPassword;
extern NSString* RVEventSubscriptionLastError;
extern NSString* RVEventAdaptiveSessionBitrate;
extern NSString* RVEventAdaptiveSessionChannel;
extern NSString* RVEventAdaptiveSessionEvent;
extern NSString* RVEventAdaptiveSessionError;

// states strings
extern NSString* RVSessionStateInactive;
extern NSString* RVSessionStateSigningIn;
extern NSString* RVSessionStateJoining;
extern NSString* RVSessionStateJoined;
extern NSString* RVSessionStateContacting;
extern NSString* RVSessionStateBuffering;
extern NSString* RVSessionStateWaitingKeyFrame;
extern NSString* RVSessionStatePlaying;

extern NSString* RVSessionMediaStateInactive;
extern NSString* RVSessionMediaStateContacting;
extern NSString* RVSessionMediaStateBuffering;
extern NSString* RVSessionMediaStateStreaming;

extern NSString* RVServiceStateSignedOut;
extern NSString* RVServiceStateSigningIn;
extern NSString* RVServiceStateSignedIn;
extern NSString* RVServiceStateSigining;

extern NSString* RVSessionErrorSessionUnknown;
extern NSString* RVSessionErrorNoChannel;
extern NSString* RVSessionErrorInvalidChannel;
extern NSString* RVSessionErrorUserPermission;
extern NSString* RVSessionErrorContainerPermission;
extern NSString* RVSessionErrorIpPermission;
extern NSString* RVSessionErrorChannelOffline;
extern NSString* RVSessionErrorMedia;
extern NSString* RVSessionErrorStandaloneUnallowed;
extern NSString* RVSessionErrorChannelBusy;
extern NSString* RVSessionErrorSubscriptionTokenRequired;
extern NSString* RVSessionErrorInvalidSubscriptionToken;
extern NSString* RVSessionErrorSubscriptionTokenExpired;
extern NSString* RVSessionErrorUpgradeRequired;
extern NSString* RVSessionErrorInvalidSubscriptionCredentials;
extern NSString* RVSessionErrorInvalidSubscriptionSecurityCode;
extern NSString* RVSessionErrorSubscriptionRequestFailed;

extern NSString* RVServiceErrorUnknown;
extern NSString* RVServiceErrorConnection;
extern NSString* RVServiceErrorAuthentication;
extern NSString* RVServiceErrorOldVersion;
extern NSString* RVServiceErrorExpired;
extern NSString* RVServiceErrorReplaced;


