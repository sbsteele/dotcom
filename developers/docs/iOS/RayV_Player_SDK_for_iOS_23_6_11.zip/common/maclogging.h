
//#pragma once

#define RAYVLOG_FILE			[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String]
#define RAYVLOG_LOCATION		RAYVLOG_FILE, __FUNCTION__, __LINE__
#define RAYVLOG_MESSAGE(...)	[[NSString stringWithFormat:__VA_ARGS__] UTF8String]

#ifdef RAYVANTILOGGER
#define RAYVLOG_DEBUG(...)
#define RAYVLOG_INFO(...)
#define RAYVLOG_WARN(...)
#define RAYVLOG_ERROR(...)
#define RAYVLOG_FATAL(...)
#else
#define RAYVLOG_DEBUG(...)		RayVLog("DEBUG", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_INFO(...)		RayVLog("INFO",  RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_WARN(...)		RayVLog("WARN",  RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_ERROR(...)		RayVLog("ERROR", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_FATAL(...)		RayVLog("FATAL", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#endif

#define RAYVLOG_DEBUG_AND_SUPPORT(...)	RayVSupportLog("DEBUG", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_INFO_AND_SUPPORT(...)	RayVSupportLog("INFO",  RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_WARN_AND_SUPPORT(...)	RayVSupportLog("WARN",  RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_ERROR_AND_SUPPORT(...)	RayVSupportLog("ERROR", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))
#define RAYVLOG_FATAL_AND_SUPPORT(...)	RayVSupportLog("FATAL", RAYVLOG_LOCATION, RAYVLOG_MESSAGE(__VA_ARGS__))

#ifdef __cplusplus
extern "C" 
#endif
void RayVLog(const char *level, const char *file, const char *function, int line, const char *message);

#ifdef __cplusplus
extern "C" 
#endif
void RayVSupportLog(const char *level, const char *file, const char *function, int line, const char *message);

void RayVLogSetup(void);

