    //
//  ChannelPlayerController.m
//  iPhoneTest
//
//  Created by ost on 9/28/10.
//  Copyright 2010 RayV. All rights reserved.
//

#import "iOS_SDK_ChannelPlayerController.h"
#import "RVMoviePlayerController.h"

#define kOFFSET_FOR_KEYBOARD 105.0

@implementation iOS_SDK_ChannelPlayerController

- (id)initWithChannel:(NSString*)channel
{
	[super init];
	
	NSURL* url = [NSURL URLWithString:[NSString stringWithFormat:@"rayv:%@", channel]];
	m_rvMoviePlayer = [[RVMoviePlayerController alloc] initWithContentURL:url];
	
	self.title = @"Tab1";
	UITabBarItem* item = [[UITabBarItem alloc] initWithTitle:@"Player" image:nil tag:0];
	self.tabBarItem = item;
	[item release];
	
	return self;
}

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void)createChannelInfo
{
	CGRect textFrame = CGRectMake(10, m_rvMoviePlayer.view.frame.size.height + 10, m_rvMoviePlayer.view.frame.size.width - 20, 25);
	m_channelInfo = [[UILabel alloc] initWithFrame:textFrame];
	m_channelInfo.backgroundColor = [UIColor grayColor];
	NSString *urlString = [[m_rvMoviePlayer contentURL] absoluteString];
	[m_channelInfo setText:urlString];
	[self.view addSubview:m_channelInfo];
}

-(void)createTextField
{
	CGRect textFrame = CGRectMake(10, m_channelInfo.frame.origin.y + 30, m_rvMoviePlayer.view.frame.size.width /2, 25);
	m_textField = [[UITextField alloc] initWithFrame:textFrame];
	m_textField.borderStyle = UITextBorderStyleRoundedRect;
	m_textField.delegate = self;
	m_textField.placeholder = @"Enter Channel...";
	[m_textField clearsOnBeginEditing];
	[self.view addSubview:m_textField];
}

-(void)createOkButton
{
	CGRect textFrame = CGRectMake(m_textField.frame.size.width + 20, m_textField.frame.origin.y, 100, 25);
	UIButton *channelButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	channelButton.frame = textFrame;
	[channelButton setTitle:@"OK" forState:UIControlStateNormal];
	[channelButton addTarget:self action:@selector(buttonOkClicked:) forControlEvents:UIControlEventTouchUpInside];
	[channelButton sizeToFit];
	[self.view addSubview:channelButton];
}

-(void)createFullscreenButton
{
	CGRect btnFrame = CGRectMake(10, m_textField.frame.origin.y + 35, 100, 25);
	UIButton *fullscreenButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	fullscreenButton.frame = btnFrame;
	[fullscreenButton setTitle:@"Fullscreen" forState:UIControlStateNormal];
	[fullscreenButton addTarget:self action:@selector(buttonFullscreenClicked:) forControlEvents:UIControlEventTouchUpInside];
	[fullscreenButton sizeToFit];
	[self.view addSubview:fullscreenButton];
}

-(void)createPlayerStateButton
{
	CGRect btnFrame = CGRectMake(120, m_textField.frame.origin.y + 35, 100, 25);
	m_playerStateBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
	m_playerStateBtn.frame = btnFrame;
	[m_playerStateBtn setTitle:@"Pause" forState:UIControlStateNormal];
	[m_playerStateBtn addTarget:self action:@selector(buttonPlayerStateClicked:) forControlEvents:UIControlEventTouchUpInside];
	[m_playerStateBtn sizeToFit];
	[self.view addSubview:m_playerStateBtn];
	
}

- (void)loadTestView
{
	[self createChannelInfo];
	[self createTextField];
	[self createOkButton];
	[self createFullscreenButton];
	[self createPlayerStateButton];
}

//method to move the view up/down whenever the keyboard is shown/dismissed 
-(void)setViewMovedUp:(BOOL)movedUp 
{ 
	[UIView beginAnimations:nil context:NULL]; 
	[UIView setAnimationDuration:0.2]; // if you want to slide up the view 
	
	CGRect rect = self.view.frame; 
	if (movedUp) 
	{ 
		// 1. move the view's origin up so that the text field that will be hidden come above the keyboard  
		// 2. increase the size of the view so that the area behind the keyboard is covered up. 
		rect.origin.y -= kOFFSET_FOR_KEYBOARD; 
		rect.size.height += kOFFSET_FOR_KEYBOARD; 
	} 
	else 
	{ 
		// revert back to the normal state. 
		rect.origin.y += kOFFSET_FOR_KEYBOARD; 
		rect.size.height -= kOFFSET_FOR_KEYBOARD; 
	} 
	self.view.frame = rect; 
	
	[UIView commitAnimations]; 
} 

-(void) changeChannel
{
	NSURL* urlString = [NSURL URLWithString:[NSString stringWithFormat:@"rayv:%@",m_textField.text]]; 
	[m_rvMoviePlayer setContentURL:urlString];
	[m_channelInfo setText:[urlString absoluteString]];
}

- (void) buttonOkClicked:(id)sender
{	
	[m_textField resignFirstResponder];
	[self changeChannel];
}

- (void)buttonFullscreenClicked:(id)sender
{
	[m_rvMoviePlayer setFullscreen:YES];
}

-(void)buttonPlayerStateClicked:(id)sender
{
	switch (m_rvMoviePlayer.playbackState) {
		case MPMoviePlaybackStatePlaying:
			[m_rvMoviePlayer pause];
			[m_playerStateBtn setTitle:@"Play" forState:UIControlStateNormal];
			break;
		case MPMoviePlaybackStatePaused:
			[m_rvMoviePlayer play];
			[m_playerStateBtn setTitle:@"Pause" forState:UIControlStateNormal];
			break;
		default:
			[m_rvMoviePlayer play];
			[m_playerStateBtn setTitle:@"Pause" forState:UIControlStateNormal];
			break;
	}
}

-(void)willEnterFullscreen:(NSNotification*)notification
{
	NSLog(@"willEnter Fullscreen");	
}

-(void)didEnterFullscreen:(NSNotification*)notification
{
	NSLog(@"didEnter Fullscreen");
}

-(void)willExitFullscreen:(NSNotification*)notification
{
	NSLog(@"willExit Fullscreen");
}

-(void)didExitFullscreen:(NSNotification*)notification
{
	NSLog(@"didExit Fullscreen");
}

-(void)playbackStateDidChange:(NSNotification*)notification
{
	RVMoviePlayerController *moviePlayer = [notification object];
	MPMoviePlaybackState playbackState = moviePlayer.playbackState;
	
	switch (playbackState) {
		case MPMoviePlaybackStatePlaying:
			NSLog(@"Movie PlaybackState Playing");
			[m_playerStateBtn setTitle:@"Pause" forState:UIControlStateNormal];
			break;
		case MPMoviePlaybackStatePaused:
			NSLog(@"Movie PlaybackState Paused");
			[m_playerStateBtn setTitle:@"Play" forState:UIControlStateNormal];
			break;
		case MPMoviePlaybackStateStopped:
			NSLog(@"Movie PlaybackState Stopped");
			break;
		case MPMoviePlaybackStateInterrupted:
			NSLog(@"Movie PlaybackState Interrupted");
			break;
		case MPMoviePlaybackStateSeekingForward:
			NSLog(@"Movie PlaybackState SeekingForward");
			break;
		case MPMoviePlaybackStateSeekingBackward:
			NSLog(@"Movie PlaybackState SeekingBackward");
			break;
		default:
			NSLog(@"Movie PlaybackState Stopped");
			break;
	}
	
}

-(void)loadStateDidChange:(NSNotification*)notification
{
	RVMoviePlayerController *moviePlayer = [notification object];
	MPMovieLoadState loadState = moviePlayer.loadState;
	
	if(loadState & MPMovieLoadStatePlayable)
	{
		NSLog(@"Movie LoadState Playable");
	}
	
	if(loadState & MPMovieLoadStatePlaythroughOK)
	{
		NSLog(@"Movie LoadState Playthrough OK");
	}
	
	if(loadState & MPMovieLoadStateStalled)
	{
		NSLog(@"Movie LoadState Stalled");
	}
	
	if(loadState & MPMovieLoadStateUnknown)
	{
		NSLog(@"Movie LoadState Unknown");
	}
	
}

-(void)scalingModeDidChange:(NSNotification*)notification
{
	RVMoviePlayerController *moviePlayer = [notification object];
	MPMovieScalingMode scalingMode = moviePlayer.scalingMode;
	
	switch (scalingMode) {
		case MPMovieScalingModeAspectFit:
			NSLog(@"Movie ScalingMode Aspect Fit");
			break;
		case MPMovieScalingModeAspectFill:
			NSLog(@"Movie ScalingMode Aspect Fill");
			break;
		case MPMovieScalingModeNone:
			NSLog(@"Movie ScalingMode None");
			break;
		case MPMovieScalingModeFill:
			NSLog(@"Movie ScalingMode Fill");
			break;
		default:
			NSLog(@"Movie ScalingMode None");
			break;
	}
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];

	CGRect r = self.view.bounds;
	r.size.height = r.size.height / 2;
	m_rvMoviePlayer.view.frame = r;
	[self.view addSubview:m_rvMoviePlayer.view];
	
	[m_rvMoviePlayer rvMakeRotateViewByOrientation:self.interfaceOrientation];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(willEnterFullscreen:) 
												 name:RVMoviePlayerWillEnterFullscreenNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(willExitFullscreen:) 
												 name:RVMoviePlayerWillExitFullscreenNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(didEnterFullscreen:) 
												 name:RVMoviePlayerDidEnterFullscreenNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(didExitFullscreen:) 
												 name:RVMoviePlayerDidExitFullscreenNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(playbackStateDidChange:) 
												 name:RVMoviePlayerPlaybackStateDidChangeNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(loadStateDidChange:) 
												 name:RVMoviePlayerLoadStateDidChangeNotification 
											   object:m_rvMoviePlayer];
	
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(scalingModeDidChange:) 
												 name:RVMoviePlayerScalingModeDidChangeNotification 
											   object:m_rvMoviePlayer];
	[self loadTestView];
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{	
	[m_rvMoviePlayer rvMakeRotateViewByOrientation:toInterfaceOrientation];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Overriden to allow any orientation.
    return YES;
}

-(BOOL)textFieldShouldReturn:(UITextField*) textField
{
	[m_textField resignFirstResponder];
	[self changeChannel];
	return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)sender
{
	if ([sender isEqual:m_textField]) 
	{ 
		//move the main view, so that the keyboard does not hide it. 
		if  (self.view.frame.origin.y >= 0) 
		{ 
			[self setViewMovedUp:YES]; 
		} 
	} 
}

-(void)textFieldDidEndEditing:(UITextField *)sender
{
	if ([sender isEqual:m_textField]) 
	{ 
		//move the main view, so that the keyboard does not hide it. 
		if  (self.view.frame.origin.y <= 0) 
		{ 
			[self setViewMovedUp:NO]; 
		} 
	} 
}

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self name:RVMoviePlayerDidExitFullscreenNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:RVMoviePlayerDidEnterFullscreenNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:RVMoviePlayerWillExitFullscreenNotification object:nil];
	[[NSNotificationCenter defaultCenter] removeObserver:self name:RVMoviePlayerWillEnterFullscreenNotification object:nil];
	
	m_textField.delegate = nil;
	
	[m_channelInfo release];
	[m_textField release];
	[m_playerStateBtn release];
	[m_rvMoviePlayer release];
	
	[super dealloc];
	
}


@end
