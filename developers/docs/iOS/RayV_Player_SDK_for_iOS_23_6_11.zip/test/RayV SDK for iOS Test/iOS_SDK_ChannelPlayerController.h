//
//  ChannelPlayerController.h
//  iPhoneTest
//
//  Created by ost on 9/28/10.
//  Copyright 2010 RayV. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RVMoviePlayerController;

@interface iOS_SDK_ChannelPlayerController : UIViewController<UITextFieldDelegate> {
	
	RVMoviePlayerController* m_rvMoviePlayer;
	
	UILabel* m_channelInfo;
	UITextField* m_textField;
	UIButton* m_playerStateBtn;
}

- (id)initWithChannel:(NSString*)channel;

@end
