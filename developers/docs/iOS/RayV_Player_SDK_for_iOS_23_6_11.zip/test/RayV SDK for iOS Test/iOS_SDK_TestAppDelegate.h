//
//  iOS_SDK_TestAppDelegate.h
//  RayV SDK for iOS test
//
//  Created by Danny Pivnik on 13/9/10.
//  Copyright RayV 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "IPhonePlayerCore.h"

@class SupportInfoController;

@interface iOS_SDK_TestAppDelegate : NSObject <UIApplicationDelegate, UITabBarControllerDelegate>
{
    UIWindow *window;
	IPhonePlayerCore* m_playerCore;
	SupportInfoController* m_supportInfoController;
	UITabBarController* m_tabBarController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

