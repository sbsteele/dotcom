//
//  iOS_SDK_TestAppDelegate.m
//  RayV SDK for iOS test
//
//  Created by Danny Pivnik on 13/9/10.
//  Copyright RayV 2010. All rights reserved.
//

#import "iOS_SDK_TestAppDelegate.h"
#import "iOS_SDK_ChannelPlayerController.h"
#import "SupportInfoController.h"

@implementation iOS_SDK_TestAppDelegate

@synthesize window;

-(void) initTabBarController
{
	NSString* channel = @"iphone1demo";
	iOS_SDK_ChannelPlayerController* channelPlayer = [[iOS_SDK_ChannelPlayerController alloc] initWithChannel:channel];
	channelPlayer.title = @"Player";
	
	m_supportInfoController = [[SupportInfoController alloc] init];
	m_supportInfoController.title = @"Info";
		
	UINavigationController* navController = [[UINavigationController alloc] initWithRootViewController:m_supportInfoController];
	
	m_tabBarController = [[UITabBarController alloc] init];
	[m_tabBarController setViewControllers:[NSArray arrayWithObjects:channelPlayer, navController, nil] animated:YES];
	m_tabBarController.delegate = self;
	[window addSubview:m_tabBarController.view];
	
	[channelPlayer release];
	[navController release];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{    
	// change "rayv" to your own distributor string and the version to your application version
	m_playerCore = [[IPhonePlayerCore alloc] initWithDistirbutor:@"rayv" versionMajor:1 versionMinor:0 versionRevision:0 versionBuild:0];
	[m_playerCore start];

	[self initTabBarController];

	[window makeKeyAndVisible];
	
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
	if (viewController == m_supportInfoController)
		[m_supportInfoController refresh:nil];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	[self release];
}

- (void)dealloc
{
    [m_supportInfoController release];
	[m_tabBarController release];
	[window release];
	[m_playerCore stop];
	[m_playerCore release];
    [super dealloc];
}

@end
