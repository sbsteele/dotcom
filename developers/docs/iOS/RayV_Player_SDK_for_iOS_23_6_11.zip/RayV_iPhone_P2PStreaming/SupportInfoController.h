//
//  SupportInfoController.h
//  RayV_IPhone_Player
//
//  Created by ost on 5/12/10.
//  Copyright 2010 RayV. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SupportInfoController : UITableViewController {

	NSArray* m_supportSectionTitles;			// array of strings with titles
	NSMutableArray* m_supportSectionsKeys;		// array of arrays (one for each section) with keys
	NSMutableArray* m_supportSectionsValues;	// array of arrays (one for each section) with values
}

- (IBAction)refresh:(id)sender;

@end
