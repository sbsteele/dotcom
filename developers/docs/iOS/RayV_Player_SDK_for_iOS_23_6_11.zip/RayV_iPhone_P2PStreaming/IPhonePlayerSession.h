//
//  IPhonePlayerSession.h
//  RayV_IPhone_Player
//
//  Created by ost on 1/27/10.
//  Copyright 2010 RayV. All rights reserved.
//

// viewing session notifications, notification details will be delivered in NSNotification userInfo dictionary
extern NSString* ViewsingSessionSessionStateDidChangeNotification;
extern NSString* ViewsingSessionSessionChannelSwitchNotification;
extern NSString* ViewsingSessionSubscriptionTokenRequired;

@protocol IPhonePlayerSessionMediaDelegate

#ifdef __cplusplus	
class MediaSample;
class iPhoneFrameReceiver;
class ICryptoMedia;
class IKeyProvider;
- (void)receiveSample:(MediaSample*)sample;
#endif

@end

@interface IPhonePlayerSession : NSObject
#ifdef __cplusplus	
<ViewerCoreEventHandlerDelegate>
#endif
{
#ifdef __cplusplus	
	IAdaptiveViewingSessionEx *m_adaptiveViewingSessionEx;
	IAdaptiveViewingSession *m_adaptiveViewingSession;
	ViewerCoreEventHandler	*m_eventHandler;
	iPhoneFrameReceiver	*m_iPhoneFrameReceiver;
	ICryptoMedia *m_cryptoMedia;
	IKeyProvider *m_keyProvider;
#endif
	
	id <IPhonePlayerSessionMediaDelegate> m_mediaDelegate;
	NSTimer *m_getFrameTimer;
	BOOL	m_active;
}

- (id)initWithMediaDelegate:(id<IPhonePlayerSessionMediaDelegate>)delegate;
- (NSString*)sessionState;
- (NSString*)mediaState;
- (void)setActive:(BOOL)activate;
- (void)setChannel:(NSString*)channel;
- (NSString*)channel;
- (void)addChannel:(NSString*)channel bitrate:(int)bitrate;
- (int)recommendedInitialBitrate;
- (void)switchChannel:(int)bitrate;
- (long)timeTillData;
- (unsigned int)expectedFrames;
- (unsigned int)receivedFrames;
- (void)setKeyServer:(NSString*)key;

@end
