//
//  RVMoviePlayerController.h
//  RayV SDK for iOS Test
//
//  Created by Danny Pivnik on 9/22/10.
//  Copyright 2010 RayV. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpStreamer.h"
#import <MediaPlayer/MediaPlayer.h>

@class RVMoviePlayerOverlay;
@class P2PInfoController;

extern NSString* RVMoviePlayerDidEnterFullscreenNotification;
extern NSString* RVMoviePlayerDidExitFullscreenNotification;
extern NSString* RVMoviePlayerWillEnterFullscreenNotification;
extern NSString* RVMoviePlayerWillExitFullscreenNotification;

extern NSString* RVMoviePlayerScalingModeDidChangeNotification;
extern NSString* RVMoviePlayerLoadStateDidChangeNotification;
extern NSString* RVMoviePlayerPlaybackStateDidChangeNotification;

@interface RVMoviePlayerController : NSObject <HttpStreamerDelegate>
{
	
@private

	UIView* m_view;
	MPMoviePlayerController* m_moviePlayer;
	HttpStreamer* m_httpStreamer;
	
	RVMoviePlayerOverlay* m_overlay;
	UIActivityIndicatorView* m_activityIndicatorView;
	UIButton* m_infoButton; 
	UILabel* m_playerStateLabel;

	P2PInfoController* m_p2pInfoController;
	NSURL* m_contentURL;
	
	UIInterfaceOrientation m_orientation;
}

@property(nonatomic, readonly) UIView *view;
@property(nonatomic, retain) NSURL *contentURL;

@property(nonatomic) BOOL fullscreen;
@property(nonatomic, readonly) MPMoviePlaybackState playbackState;
@property(nonatomic, readonly) MPMovieLoadState loadState;
@property(nonatomic) MPMovieScalingMode scalingMode;

- (id) initWithContentURL:(NSURL *)url;
- (void)play;
- (void)pause;
- (void) rvMakeRotateViewByOrientation:(UIInterfaceOrientation)interfaceOrientation;

@end