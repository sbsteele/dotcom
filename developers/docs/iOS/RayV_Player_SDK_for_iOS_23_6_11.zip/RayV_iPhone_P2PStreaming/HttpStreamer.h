//
//  HttpStreamer.h
//  RayV_IPhone_Player
//
//  Created by ost on 1/20/10.
//  Copyright 2010 RayV. All rights reserved.
//

#import "IPhonePlayerSession.h"

#ifdef __cplusplus
class MediaSample;
class ProgramMediaInfo;
#endif
@class MpegTsFile;
@class HTTPServer;

//#define START_WITH_KEYFRAME		// define to start files with key frames (ignore duration bellow)
#ifdef START_WITH_KEYFRAME
#define MPEG_TS_DURATION 6			// should be set to what keyframe frequency of channel is
#else
#define MPEG_TS_DURATION 1			// fixed duration for mpeg-ts files
#endif
#define MIN_MPEG_TS_FILES 3			// number of files to create before starting to stream
#define MAX_MPEG_TS_FILES 20		// number of files to keep before deleting the old ones

@protocol HttpStreamerDelegate

- (void)mediaSegmentsReady;								// playlist is ready with enough segments to start playing
- (void)sessionStateDidChange:(NSDictionary*)event;		// viewsing session changed state, event keys/values in ViewerCoreEvents.h

@end

@interface HttpStreamer : NSObject <IPhonePlayerSessionMediaDelegate> {
	
@private

	IPhonePlayerSession* m_session;					// viewing session
	NSString* m_sessionState;						// session state - combined from session, media and HttpStreamer states.
	
	MpegTsFile* m_mpegtsFile;						// mpeg-ts file muxer
	long m_firstFileIndex;							// index of first file, 0 if no files yet
	long m_filesCount;								// number of files
	int m_fileDurartions[MAX_MPEG_TS_FILES];		// durations, rounded to seconds, of current files
	BOOL m_fileDiscontinuities[MAX_MPEG_TS_FILES];	// discontinuity flag per file
	int m_currentDurationIndex;						// index of current file in the duration array
	
#ifdef __cplusplus
	ProgramMediaInfo* m_programMediaInfo;	// latest program media info or NULL
#endif

	BOOL m_started;
	NSTimer* m_maxFileTimer;				// timer to make sure files are not too long
	id <HttpStreamerDelegate> m_delegate;
	HTTPServer* m_httpServer;
	
	BOOL m_gotKeyFrame;						// set to true when got a keyframe, to false when there is video frame loss so can drop all frames until key frame
	
	int64_t m_lastAudioIndex;				// last received audio sample number
	int64_t m_lastVideoIndex;				// last received video sample number
}

- (id)initWithDelegate:(id <HttpStreamerDelegate>)delegate;	// initialize with delegate to receive callbacks defined in HttpStreamerDelegate protocol
- (void)start;												// start streamer. stream can be safely used only after mediaSegmentsReady is called
- (void)stop;												// stop steamer and dellocate all resources, can call start again later
- (void)setSessionActive:(BOOL)activate;					// starts or stops the P2P viewing session.

// HTTP Server
@property (readonly, nonatomic) int port;					// port to used for local HTTP streaming

// viewing session stuff
@property (assign, nonatomic) NSString* channel;			// channel ID, should be set before calling setSessionActive, can be changed to switch channels
@property (readonly, nonatomic) NSString* sessionState;		// viewing session state, look at ViewerCoreEvents.h for possible values 
@property (readonly, nonatomic) NSString* mediaState;			// viewing session media state, look at ViewerCoreEvents.h for possible values
@property (readonly, nonatomic) unsigned int expectedFrames;	// media samples expected to be received so far
@property (readonly, nonatomic) unsigned int receivedFrames;	// media samples received, can tell how many samples were lost by comparing to expectedFrames

@end
