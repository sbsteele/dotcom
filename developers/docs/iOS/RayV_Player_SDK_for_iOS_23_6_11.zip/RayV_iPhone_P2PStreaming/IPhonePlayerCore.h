//
//  IPhonePlayerCore.h
//  RayV_IPhone_Player
//
//  Created by ost on 1/27/10.
//  Copyright 2010 RayV. All rights reserved.
//

// notification name for service state change, state details will be delivered in NSNotification userInfo dictionary
extern NSString* ViewerCoreServiceStateDidChangeNotification;

// network connection types
typedef enum
{
	RVNetworkConnectionNone = 0,
	RVNetworkConnectionWiFi,
	RVNetworkConnectionWWAN
	
} RVNetworkConnectionType;

@class Reachability;

@interface IPhonePlayerCore : NSObject
#ifdef __cplusplus
<ViewerCoreEventHandlerDelegate>
#endif
{
	NSString* m_distributor;
	Reachability* m_reachability;
	BOOL m_usingWwan;
	NSTimer* m_reachabilityTimer;
	int m_versionMajor, m_versionMinor, m_versionRevision, m_versionBuild;
}

// the one and only player core instance
+ (IPhonePlayerCore*)sharedIPhonePlayerCore;

// inialize player core with distributor and player version (major.minor.revision.build for example 1.01.123)
- (id)initWithDistirbutor:(NSString*)distributor versionMajor:(int)major versionMinor:(int)minor versionRevision:(int)revision versionBuild:(int)build;

// start player core (creates and initialize RayV Player SDK)
- (void)start;

// stop player core (destroys RayV Player SDK). Can call start again after stop.
- (void)stop;

// RayV Player SDK version
@property (readonly, nonatomic) NSString* version;

// Get status of connection to RayV Grid, see ViewerCoreEvents.h for possible values
@property (readonly, nonatomic) NSString* serviceState;

// Get RayV Player SDK internal information for debugging and support. Possible values for type are: "support"
- (NSDictionary*)infoOfType:(NSString*)type;

// get the maximum bitrate supported on this device
- (int)maxSupportedBitrate;

// get current network connection
- (RVNetworkConnectionType)networkConnectionType;

// get contents of the support log
- (NSString*)supportLog;

@end
